//
//  XPEmptySequence.h
//  Panthro
//
//  Created by Todd Ditchendorf on 7/5/14.
//
//

#import "XPAtomicSequence.h"

@interface XPEmptySequence : XPAtomicSequence

+ (instancetype)instance;
@end
