//
//  XPRootExpression.h
//  Panthro
//
//  Created by Todd Ditchendorf on 5/4/14.
//
//

#import "XPSingletonExpression.h"

@interface XPRootExpression : XPSingletonExpression

@end
