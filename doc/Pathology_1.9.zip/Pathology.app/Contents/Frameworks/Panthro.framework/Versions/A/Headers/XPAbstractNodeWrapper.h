//
//  XPAbstractNodeWrapper.h
//  Panthro
//
//  Created by Todd Ditchendorf on 7/4/14.
//
//

#import <Panthro/XPNodeInfo.h>

@interface XPAbstractNodeWrapper : NSObject <XPNodeInfo>

@end
