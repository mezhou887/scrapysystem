//
//  XPSequenceValue.h
//  Panthro
//
//  Created by Todd Ditchendorf on 7/14/09.
//  Copyright 2009 Todd Ditchendorf. All rights reserved.
//

#import "XPValue.h"

@interface XPSequenceValue : XPValue

- (NSUInteger)count;

@end
