//
//  XPEmptyNodeSet.h
//  Panthro
//
//  Created by Todd Ditchendorf on 5/4/14.
//
//

#import <Panthro/XPNodeSetValue.h>

@interface XPEmptyNodeSet : XPNodeSetValue

+ (instancetype)instance;
@end
